#!/usr/bin/env bash
sudo timedatectl set-timezone America/Denver
